import java.util.Scanner;
public class Secondone
{
public static void main(String args[])
{
int i=0,j=0,sum=0,value=0;
Scanner sc=new Scanner(System.in);
System.out.println("enter value of N");
int number=sc.nextInt();
for(i=1;i<=number;i++)
{
System.out.println("enter numbers:");
value=sc.nextInt();
if(value>0)
{
j++;
sum=sum+value;
}
}
System.out.println("not positive numbers:"+j);
System.out.println("Sum of positive num:"+sum);
}
}