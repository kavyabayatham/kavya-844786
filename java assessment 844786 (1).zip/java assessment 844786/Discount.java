import java.util.*;
class Discount
{
public static void main(String args[])
{
	double dis=20,no1,no2,no3,s,markedprice,temp,res,small,amount;
	Scanner sc=new Scanner(System.in);
	System.out.println("enter markedprice");
	no1=sc.nextDouble();
	no2=sc.nextDouble();
	no3=sc.nextDouble();
	markedprice=no1+no2+no3;
	System.out.println("total amount="+markedprice);
	s=100-dis;
	amount=(s*markedprice)/100;
	System.out.println("Offer 1="+amount);
	temp=no1<no2?no1:no2;
	small=no3<temp?no3:temp;
	res=markedprice-small;
	System.out.println("Offer 2="+res);
	if(amount<res)
	{
		System.out.println("use offer 1");
	}
else
	{
		System.out.println("use offer 2");
	}
}
}