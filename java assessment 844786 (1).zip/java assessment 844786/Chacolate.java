import java.util.Scanner;
class Chacolate{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
int choco=sc.nextInt();
int child=sc.nextInt();
for(int i=1;i<=child;i++){
if(choco>=i){
choco=choco-i;
}
else{
int n=child-(i-1);
System.out.println("Chocolate remains "+choco);
System.out.println("number of person remaining "+n);
break;
}
}
}
}