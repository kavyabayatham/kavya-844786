import java.util.Scanner;
class Firstone
{
public static boolean check(int num)
	{
	int i,flag=0;
	for(i=2;i<=num/2;i++)
	{
		if(num%i==0)
		{
			flag=1;
			break;
		}
	}
	if(flag==0)
		return true;
	else
		return false;
	}
public static void main(String[] args)
{
	Scanner s=new Scanner(System.in);
	System.out.println("enter prime number range");
	int n=s.nextInt();
	int count=0;
	for(int num=2;num<n;num++)
	{
	if(check(num)==true)
	{
	if(count%2==0)
	System.out.println(num+" ");
	count++;
}
}
}
}
