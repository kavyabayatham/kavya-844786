import java.util.Scanner;
public class Ninethone
{
public static void main(String args[])
{
int i;
Scanner sc=new Scanner(System.in);
System.out.println("enter first_no");
int first_no=sc.nextInt();
System.out.println("enter last_no");
int last_no=sc.nextInt();
for(i=first_no;i<=last_no;i++)
{
System.out.println(i);
}
}
}