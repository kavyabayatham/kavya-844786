import java.util.Scanner;
public class Thirdone {
    public static void main(String args[])
    {  int first=0,second=0,final_route=0;
        Scanner input = new Scanner(System.in);
        System.out.println("the bird said : ");
        
        int message_digit=input.nextInt();
        first=message_digit%10;
        second=message_digit/10;
        final_route=first+second;
        
        System.out.println("Pattrick and Johnny must go in path - "+final_route +" to find alice");
    }
    
}
